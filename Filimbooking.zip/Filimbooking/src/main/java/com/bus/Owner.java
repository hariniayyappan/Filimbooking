package com.bus;

public class Owner {

	public Object getEmail1() {
		// TODO Auto-generated method stub
		return null;
	}

	public Object getEmail() {
		// TODO Auto-generated method stub
		return null;
	}

}
